nếu muốn thay đổi ảnh hãy xóa ảnh cũ trong folder:images đi 
rồi kéo ảnh của bạn vào trong folder 
đổi tên ảnh của bạn lần lượt thành image 1-5 
nếu đuôi ảnh của bạn khác jpeg thì hãy vào file script.js trong folder js và vào dòng 88 để sửa lại đuôi ảnh 

đổi câu chúc trong dòng 547 file script.js